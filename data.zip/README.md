# Viết bài Hướng đạo (Kotlin + Jetpack Compose)

App Android gọi Gemini API (model `gemini-4-hydrogen`) để hỗ trợ viết bài cho Phong trào Hướng đạo.

## Trạng thái
Mã nguồn đầy đủ chức năng nhưng **chưa từng được biên dịch hoặc chạy** (môi trường soạn thảo không có Android SDK).
Đã kiểm tra: không có lỗi cú pháp Kotlin. Chưa kiểm tra: biên dịch với thư viện thật, gọi API thật, giao diện trên máy.

## Chạy thử
1. Android Studio bản mới, Gradle JDK 17. Mở thư mục `ScoutWriter`, chờ Sync.
   Nếu Studio báo version AGP/Kotlin/Compose BOM cũ, chấp nhận nâng (file `build.gradle.kts`, `app/build.gradle.kts`).
   Gradle wrapper 8.9 (`gradlew`, `gradle/wrapper/gradle-wrapper.jar`) lấy từ repo chính thức `gradle/gradle`, tag `v8.9.0`. SHA-256 của jar: `498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17`; đối chiếu với bảng checksum tại gradle.org/release-checksums.
2. Chạy trên máy thật hoặc emulator API 26+.
3. Menu ⋮ > Cài đặt > dán API key tạo tại Google AI Studio > "Kiểm tra kết nối".

## Chức năng đã có
| Yêu cầu | Nơi thực hiện |
|---|---|
| Skills (quy tắc viết bài) | Menu > Skills. Quy tắc chung + quy tắc riêng từng thể loại, sửa và khôi phục mặc định |
| 7 thể loại, mỗi loại theo skills | `Genre` (Models.kt), `Defaults.GENRE_SKILLS` |
| Phong cách: 7 mẫu + tuỳ chọn | `Defaults.STYLES`, ô "Tuỳ chọn" ở màn hình chính |
| Chọn bài cũ để viết tiếp / tạo mới | Menu > Bài đã tạo; nút "Viết tiếp"; "Dán bài có sẵn" cho bài viết từ nơi khác |
| Ô brief và từ khoá | Màn hình chính |
| Generate, mỗi lần một phiên bản | Chip v1, v2, ...; góc mở bài đổi mỗi lần, tránh lặp mở bài các bản trước |
| Điều chỉnh: cô đọng, cụ thể, sâu sắc, thực tiễn | Nút dưới phần Phiên bản |
| Bài đề xuất + Copy Markdown / HTML | Màn hình chính |
| Nội dung mạng xã hội + hashtag + Copy | Màn hình chính |
| Thư viện thuật ngữ | Menu > Thuật ngữ (thêm, sửa, nhập hàng loạt `Thuật ngữ | Giải thích | Tránh`) |

## Quyết định thiết kế và giới hạn
- **Không có "đăng nhập Google để lấy API key"**: đăng nhập Google không cấp API key Gemini. Người dùng tạo key trong Google AI Studio và dán vào app; key lưu mã hoá trên máy. Không nhúng key chung vào APK.
- **"Bài cũ từ Gemini" không đọc được từ ứng dụng Gemini**: API không cung cấp lịch sử chat của app Gemini. App chỉ lưu bài do chính nó tạo; bài từ nơi khác nhập bằng "Dán bài có sẵn".
- **`temperature`, `top_p`, `top_k` bị gemini-4-hydrogen bỏ qua** (theo hướng dẫn của Google cho Hydrogen). Độ khác biệt giữa các phiên bản do prompt tạo ra (góc mở bài + danh sách mở bài đã dùng).
- **Mức suy luận mặc định MEDIUM** (model mặc định HIGH, chậm và tốn token hơn). Đổi trong Cài đặt.
- **Chống bịa dữ kiện**: prompt buộc dùng chỗ trống `[CẦN BỔ SUNG: ...]` thay cho số liệu, trích dẫn, ví dụ không có trong brief. "Thực tiễn hơn" chỉ đề xuất ví dụ dưới dạng `[GỢI Ý VÍ DỤ, cần xác minh]`. Còn đánh dấu nào thì app hiện cảnh báo trước khi đăng.
- **Bảo vệ trẻ em** nằm trong Skills (sửa được). App quét thêm số điện thoại, email; không phát hiện được họ tên trẻ em, cần người duyệt.
- **Gói miễn phí và dữ liệu**: kiểm tra điều khoản xử lý dữ liệu của gói (miễn phí hay trả phí) đang dùng trước khi nhập nội dung có liên quan đến trẻ em.
- Đang tạo bài mà chuyển app sang nền quá lâu có thể mất kết nối và phải bấm tạo lại (chưa có foreground service).

## Điểm cần kiểm tra khi chạy thật
- Endpoint `generativelanguage.googleapis.com/v1beta/models/{model}:generateContent` và trường `thinkingLevel` đã đối chiếu với tài liệu Agent Platform và hướng dẫn bên thứ ba, chưa đối chiếu trực tiếp trang tài liệu Gemini API. App thử `HIGH` → `high` → bỏ `thinkingConfig` khi gặp lỗi 400 nhắc tới "think". Nếu vẫn lỗi 400, sửa trong `Gemini.kt`.
- Danh sách thuật ngữ khởi tạo cần Ban Huấn luyện rà soát.
- Giá model và hạn mức: xem trang giá của Gemini API trước khi dùng cho cả nhóm.

## Thư mục `_archive_old_attempt`
Bản thử cũ (package `vn.scout.writer`, dùng Room) và `libs.versions.toml` cũ. Đã chuyển ra ngoài `app/src` vì cùng nằm trong source set sẽ làm build lỗi. Không dùng; xoá nếu không cần.

## Build APK trên GitHub Actions
Repo chỉ cần 2 thứ ở thư mục gốc: `data.zip` (chứa toàn bộ mã nguồn này) và `.github/workflows/build-apk.yml`. Workflow tự giải nén `data.zip`, build `app-debug.apk` và đưa vào Artifacts. Workflow chạy khi push lên `main` hoặc bấm tay ở tab Actions.

1. Tạo repo **private** trên GitHub. Add file > Upload files > kéo `data.zip` vào > Commit changes.
2. Add file > Create new file. Ở ô tên gõ `.github/workflows/build-apk.yml` (gõ dấu `/` để tạo thư mục), dán nội dung file `build-apk.yml` > Commit changes vào `main`.
3. Tab Actions > "Build APK" > chờ chạy xong > mục Artifacts > tải `ScoutWriter-debug-apk` > giải nén ra `app-debug.apk`.
4. Cài lên máy: cho phép cài từ nguồn ngoài cho ứng dụng dùng để mở file; Play Protect cảnh báo thì chọn "Vẫn cài".
5. Build lỗi: mở bước đỏ trong log, sao chép phần `error:` hoặc `What went wrong` gửi lại để sửa. Artifact `build-reports` chứa báo cáo chi tiết.
6. Cập nhật mã: upload `data.zip` mới trùng tên (ghi đè), workflow tự chạy lại.

### Khoá ký cố định (nên làm trước khi phát cho cả nhóm)
Không đặt khoá, mỗi lần build GitHub sinh một khoá debug khác nhau. Android không cho cài đè bản khác chữ ký, nên mỗi bản mới phải gỡ bản cũ và mất dữ liệu trong app (bài đã lưu, API key).
```
keytool -genkeypair -v -keystore scoutwriter.keystore -alias scoutwriter -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 scoutwriter.keystore        # Windows PowerShell: [Convert]::ToBase64String([IO.File]::ReadAllBytes("scoutwriter.keystore"))
```
Repo > Settings > Secrets and variables > Actions > New repository secret, đặt 4 secret: `KEYSTORE_BASE64` (chuỗi base64), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`scoutwriter`), `KEY_PASSWORD`. Sao lưu file keystore và mật khẩu ở nơi an toàn; mất là không cập nhật đè được nữa. Không đẩy keystore lên repo (`.gitignore` đã chặn `*.keystore`).
