package vn.huongdao.writer

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val articleRepo = ArticleRepo(app)
    private val termRepo = TermRepo(app)
    private val gemini = GeminiClient()

    var articles by mutableStateOf(articleRepo.load())
    var terms by mutableStateOf(termRepo.load())
    var currentId by mutableStateOf<String?>(null)
    var genre by mutableStateOf(Genre.TUONG_THUAT)
    var styleId by mutableStateOf("thieu_nien")
    var brief by mutableStateOf("")
    var keywords by mutableStateOf("")
    var versionIndex by mutableIntStateOf(-1)
    var busy by mutableStateOf(false)
    var errorMsg by mutableStateOf<String?>(null)
    var testResult by mutableStateOf<String?>(null)

    val current: Article? get() = articles.firstOrNull { it.id == currentId }
    val selected: Version? get() = current?.versions?.getOrNull(versionIndex)

    private fun now() = System.currentTimeMillis()
    private fun uid() = UUID.randomUUID().toString()

    // ---- bài viết ----
    fun newArticle() {
        currentId = null; brief = ""; keywords = ""; versionIndex = -1; errorMsg = null
    }

    fun open(id: String) {
        val a = articles.firstOrNull { it.id == id } ?: return
        currentId = a.id; genre = Genre.fromKey(a.genreKey); styleId = a.styleId
        brief = a.brief; keywords = a.keywords; versionIndex = a.versions.lastIndex; errorMsg = null
    }

    fun selectVersion(i: Int) { versionIndex = i }

    fun deleteArticle(id: String) {
        articles = articles.filter { it.id != id }
        if (currentId == id) newArticle()
        persist()
    }

    fun importArticle(title: String, body: String) {
        val v = Version(uid(), title.trim(), body.trim(), "", emptyList(), "", "Dán từ bên ngoài", now())
        val a = Article(uid(), genre.key, styleId, "", "", listOf(v), now())
        articles = listOf(a) + articles
        persist()
        open(a.id)
    }

    fun editSelected(title: String? = null, body: String? = null, social: String? = null) {
        val id = currentId ?: return
        val idx = versionIndex
        mutate(id) { a ->
            a.copy(versions = a.versions.mapIndexed { i, v ->
                if (i == idx) v.copy(title = title ?: v.title, body = body ?: v.body, social = social ?: v.social) else v
            })
        }
        persistSoon()
    }

    // ---- gọi Gemini ----
    fun generate() {
        val prev = current?.versions.orEmpty()
        val angle = Defaults.ANGLES.filterNot { a -> prev.any { it.label.contains(a) } }
            .ifEmpty { Defaults.ANGLES }.random()
        val openings = prev.takeLast(4).map { it.body.trim().replace("\n", " ").take(240) }
        call("Bản mới ($angle)") { PromptBuilder.create(brief, keywords, openings, angle) }
    }

    fun adjust(mode: Adjust) {
        val v = selected ?: return
        call(mode.label) { PromptBuilder.adjust(mode, v, brief, keywords) }
    }

    private fun call(label: String, userPrompt: () -> String) {
        if (busy || !ready()) return
        val art = upsert()
        busy = true; errorMsg = null
        viewModelScope.launch {
            try {
                val sys = PromptBuilder.system(prefs, genre, styleText(), terms)
                val raw = gemini.generate(prefs.apiKey, prefs.model, prefs.thinking, sys, userPrompt())
                val out = PromptBuilder.parse(raw)
                if (out.body.isBlank()) throw IllegalStateException("Gemini trả về nội dung rỗng. Bấm lại để thử lần nữa.")
                val v = Version(uid(), out.title, out.body, out.social, out.hashtags, out.notes, label, now())
                mutate(art.id) { it.copy(versions = it.versions + v, updatedAt = now()) }
                versionIndex = current?.versions?.lastIndex ?: -1
                persist()
            } catch (e: Exception) {
                errorMsg = describe(e)
            } finally {
                busy = false
            }
        }
    }

    private fun ready(): Boolean {
        if (prefs.apiKey.isBlank()) { errorMsg = "Chưa có API key. Vào Cài đặt, dán key tạo từ Google AI Studio."; return false }
        if (brief.isBlank()) { errorMsg = "Ô nội dung chính đang trống. Nhập ít nhất một ý cần viết."; return false }
        return true
    }

    private fun describe(e: Exception): String = when {
        e is java.net.UnknownHostException -> "Không có kết nối mạng. Kiểm tra Wi-Fi hoặc dữ liệu di động rồi bấm lại."
        e is java.net.SocketTimeoutException -> "Hết thời gian chờ phản hồi. Bấm lại, hoặc hạ mức suy luận xuống LOW trong Cài đặt."
        e.message.orEmpty().startsWith("HTTP 429") -> "Vượt hạn mức gọi API (HTTP 429). Đợi vài phút rồi bấm lại, hoặc kiểm tra hạn mức của key trong Google AI Studio."
        e.message.orEmpty().startsWith("HTTP 401") || e.message.orEmpty().startsWith("HTTP 403") ->
            e.message + "\nAPI key sai, hết hiệu lực hoặc chưa được cấp quyền dùng model này. Kiểm tra key trong Cài đặt."
        e.message.orEmpty().startsWith("HTTP 404") -> e.message + "\nKhông tìm thấy model. Kiểm tra tên model trong Cài đặt."
        e.message.orEmpty().startsWith("HTTP 4") -> e.message + "\nKiểm tra API key và tên model trong Cài đặt."
        else -> e.message ?: e.toString()
    }

    fun styleText(): String =
        if (styleId == "custom") prefs.customStyle.ifBlank { "Viết tự nhiên, rõ ràng, phù hợp môi trường Hướng đạo." }
        else (Defaults.STYLES.firstOrNull { it.id == styleId } ?: Defaults.STYLES.first()).prompt

    fun testConnection() {
        testResult = "Đang kiểm tra…"
        viewModelScope.launch {
            testResult = try {
                val r = gemini.generate(prefs.apiKey, prefs.model, prefs.thinking, "", "Trả lời đúng một từ: OK", json = false)
                "Kết nối được. Phản hồi: " + r.trim().take(40)
            } catch (e: Exception) {
                "Lỗi: " + describe(e)
            }
        }
    }

    // ---- thuật ngữ ----
    fun saveTerm(t: Term) {
        val item = if (t.id.isBlank()) t.copy(id = uid()) else t
        terms = if (terms.any { it.id == item.id }) terms.map { if (it.id == item.id) item else it } else terms + item
        persistTerms()
    }

    fun deleteTerm(id: String) { terms = terms.filter { it.id != id }; persistTerms() }

    /** Mỗi dòng: Thuật ngữ | Giải thích | Cách dùng cần tránh (tuỳ chọn). Trả về số dòng hợp lệ. */
    fun importTerms(text: String): Int {
        val parsed = text.lines().mapNotNull { line ->
            val p = line.split("|").map { it.trim() }
            if (p.size < 2 || p[0].isEmpty()) null else Term(uid(), p[0], p[1], p.getOrElse(2) { "" })
        }
        val keys = parsed.map { it.term.lowercase() }.toSet()
        terms = (terms.filter { it.term.lowercase() !in keys } + parsed).sortedBy { it.term.lowercase() }
        persistTerms()
        return parsed.size
    }

    // ---- lưu trữ ----
    private fun mutate(id: String, f: (Article) -> Article) {
        articles = articles.map { if (it.id == id) f(it) else it }
    }

    private fun upsert(): Article {
        val cur = current
        val a = cur?.copy(genreKey = genre.key, styleId = styleId, brief = brief, keywords = keywords)
            ?: Article(uid(), genre.key, styleId, brief, keywords, emptyList(), now())
        articles = listOf(a) + articles.filter { it.id != a.id }
        currentId = a.id
        return a
    }

    private fun persist() {
        val snap = articles
        viewModelScope.launch(Dispatchers.IO) { articleRepo.save(snap) }
    }

    private var saveJob: Job? = null
    private fun persistSoon() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(600); persist() }
    }

    private fun persistTerms() {
        val snap = terms
        viewModelScope.launch(Dispatchers.IO) { termRepo.save(snap) }
    }

    override fun onCleared() {
        articleRepo.save(articles)
    }
}
