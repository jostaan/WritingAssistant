package vn.huongdao.writer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(240, TimeUnit.SECONDS)
        .build()

    private class ApiException(val code: Int, msg: String) : Exception(msg)

    /** Gọi generateContent. temperature/top_p/top_k bị gemini-4-hydrogen bỏ qua nên không gửi. */
    suspend fun generate(
        apiKey: String, model: String, thinking: String?,
        system: String, user: String, json: Boolean = true
    ): String = withContext(Dispatchers.IO) {
        // Thứ tự thử: IN HOA (cách viết của tài liệu GenerateContent) -> chữ thường -> bỏ thinkingConfig.
        // Chỉ chuyển bước khi server báo lỗi 400 có nhắc tới "think".
        val attempts = if (thinking == null) listOf<String?>(null)
        else listOf(thinking.uppercase(), thinking.lowercase(), null)
        var last: ApiException? = null
        for (level in attempts) {
            try {
                return@withContext call(apiKey, model, level, system, user, json)
            } catch (e: ApiException) {
                val thinkingRejected = e.code == 400 && e.message.orEmpty().contains("think", ignoreCase = true)
                if (!thinkingRejected) throw e
                last = e
            }
        }
        throw last ?: IllegalStateException("Không gọi được Gemini")
    }

    private fun call(apiKey: String, model: String, thinking: String?, system: String, user: String, json: Boolean): String {
        val gen = JSONObject()
        if (json) gen.put("responseMimeType", "application/json")
        if (thinking != null) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", thinking))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", user)))))
            .put("generationConfig", gen)
        if (system.isNotBlank()) {
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        }
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(r.code, "HTTP ${r.code}: " + errorMessage(raw))
            return extractText(raw)
        }
    }

    private fun errorMessage(raw: String): String = try {
        JSONObject(raw).getJSONObject("error").optString("message", raw)
    } catch (e: Exception) { raw.take(300) }

    private fun extractText(raw: String): String {
        val root = JSONObject(raw)
        val cand = root.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw IllegalStateException(
                "Gemini không trả kết quả" +
                    (root.optJSONObject("promptFeedback")?.optString("blockReason")?.takeIf { it.isNotEmpty() }
                        ?.let { " (bị chặn: $it)" } ?: "")
            )
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("Phản hồi rỗng (finishReason=${cand.optString("finishReason")})")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return sb.toString()
    }
}

data class ParsedOutput(val title: String, val body: String, val social: String, val hashtags: List<String>, val notes: String)

object PromptBuilder {
    private val OUTPUT_SPEC = """
## Định dạng đầu ra
Chỉ trả về một đối tượng JSON hợp lệ, không thêm văn bản ngoài JSON, với đúng các khoá sau:
{"title": string, "body_markdown": string, "social_post": string, "hashtags": [string], "notes": string}
- title: tiêu đề bài.
- body_markdown: toàn văn bài viết bằng Markdown (dùng ## cho tiêu đề phụ nếu thể loại cần; không lặp lại title ở đầu).
- social_post: nội dung đăng Facebook để chia sẻ bài từ website, 60–120 từ; dòng đầu là câu móc; 2–4 ý chính; chứa các từ khoá quan trọng; kết bằng lời mời đọc bài đầy đủ trên website. Không chèn đường link, không chèn hashtag trong nội dung.
- hashtags: 4–8 hashtag viết liền, có dấu #, gồm hashtag chung của Phong trào và hashtag theo nội dung.
- notes: điểm người viết cần xác minh hoặc bổ sung, và các chỗ đã ẩn danh để bảo vệ trẻ em; chuỗi rỗng nếu không có.
""".trimIndent()

    fun system(prefs: Prefs, genre: Genre, styleText: String, terms: List<Term>): String = buildString {
        appendLine(prefs.skill(null).trim())
        appendLine()
        appendLine("## Quy tắc riêng của thể loại: ${genre.label}")
        appendLine(prefs.skill(genre).trim())
        appendLine()
        appendLine("## Phong cách viết")
        appendLine(styleText.trim())
        if (terms.isNotEmpty()) {
            appendLine()
            appendLine("## Thư viện thuật ngữ Hướng đạo (dùng đúng; mục \"tránh\" là cách dùng sai)")
            terms.take(300).forEach { t ->
                append("- ${t.term}: ${t.meaning}")
                if (t.avoid.isNotBlank()) append(" | tránh: ${t.avoid}")
                appendLine()
            }
        }
        appendLine()
        appendLine(OUTPUT_SPEC)
    }

    fun create(brief: String, keywords: String, openings: List<String>, angle: String): String = buildString {
        appendLine("## Brief")
        appendLine(brief.trim())
        appendLine()
        appendLine("## Từ khoá cần nhấn mạnh")
        appendLine(keywords.trim().ifBlank { "(không có)" })
        appendLine()
        appendLine("## Yêu cầu đa dạng")
        appendLine("Gợi ý chất liệu mở bài cho phiên bản này: $angle. Nếu thể loại đã có quy định riêng về mở bài thì theo quy định đó và chỉ dùng gợi ý này để chọn chất liệu.")
        if (openings.isNotEmpty()) {
            appendLine("Các phiên bản trước mở bài như sau; không lặp lại cấu trúc câu, hình ảnh hay cụm từ:")
            openings.forEach { appendLine("- \"$it\"") }
        }
        appendLine()
        appendLine("Viết bài hoàn chỉnh theo các quy tắc và trả về JSON.")
    }

    fun adjust(mode: Adjust, cur: Version, brief: String, keywords: String): String = buildString {
        appendLine("## Nhiệm vụ")
        appendLine(
            when (mode) {
                Adjust.CONCISE -> "Rút gọn bài dưới đây còn khoảng 60–70% độ dài. Giữ nguyên toàn bộ ý chính, dữ kiện, số liệu, tên riêng và từ khoá. Bỏ lặp và chi tiết thừa; không thêm ý mới."
                Adjust.DETAILED -> "Mở rộng bài dưới đây dài hơn khoảng 30–50%. Giải thích cụ thể hơn: ai, cái gì, vì sao, như thế nào; làm rõ khái niệm. Chỉ dựa trên brief và bài hiện tại; chỗ thiếu dữ kiện ghi [CẦN BỔ SUNG]."
                Adjust.DEEPER -> "Làm lập luận của bài sâu và sắc hơn: làm rõ luận điểm, nêu nguyên nhân và hệ quả, nêu một phản biện và đáp lại, nối với giá trị và Phương pháp Hướng đạo. Thay câu chung chung bằng nhận định cụ thể. Không thêm dữ kiện không có trong brief."
                Adjust.PRACTICAL -> "Bổ sung bằng chứng minh hoạ từ thực tiễn: ví dụ hoạt động, tình huống, hành động cụ thể. Chỉ dùng dữ kiện có trong brief hoặc bài hiện tại. Ví dụ chưa có thì đề xuất dưới dạng [GỢI Ý VÍ DỤ, cần xác minh], không trình bày như sự thật."
                Adjust.CONTINUE -> "Viết tiếp bài: giữ nguyên phần đã có, rồi phát triển tiếp những nội dung trong brief mà bài hiện tại chưa đề cập. Trả về bài đầy đủ gồm phần cũ và phần mới, liền mạch về giọng văn."
            }
        )
        appendLine("Giữ nguyên thể loại, phong cách, quy tắc bảo vệ trẻ em và thuật ngữ. Cập nhật social_post và hashtags cho khớp bài mới. Trả về toàn bộ bài (không chỉ phần thay đổi) dưới dạng JSON.")
        appendLine()
        appendLine("## Brief gốc")
        appendLine(brief.trim().ifBlank { "(không có)" })
        appendLine()
        appendLine("## Từ khoá cần nhấn mạnh")
        appendLine(keywords.trim().ifBlank { "(không có)" })
        appendLine()
        appendLine("## Bài hiện tại")
        appendLine("Tiêu đề: ${cur.title}")
        appendLine(cur.body.trim())
    }

    fun parse(raw: String): ParsedOutput {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val o = JSONObject(cleaned)
            val tags = o.optJSONArray("hashtags")
            ParsedOutput(
                o.optString("title").trim(), o.optString("body_markdown").trim(), o.optString("social_post").trim(),
                (if (tags == null) emptyList() else List(tags.length()) { tags.getString(it).trim() })
                    .filter { it.isNotEmpty() }.map { if (it.startsWith("#")) it else "#$it" },
                o.optString("notes").trim()
            )
        } catch (e: Exception) {
            ParsedOutput("", cleaned, "", emptyList(), "Phản hồi không đúng định dạng JSON nên toàn bộ nội dung nằm ở phần bài viết; mục mạng xã hội cần tạo lại.")
        }
    }
}
