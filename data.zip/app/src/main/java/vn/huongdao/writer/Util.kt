package vn.huongdao.writer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import org.commonmark.parser.Parser
import org.commonmark.renderer.html.HtmlRenderer

object Md {
    private val parser = Parser.builder().build()
    private val renderer = HtmlRenderer.builder().escapeHtml(true).build()
    fun toHtml(md: String): String = renderer.render(parser.parse(md)).trim()
    fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}

object SafetyCheck {
    private val phone = Regex("""(?<!\d)(\+?84|0)[\s.\-]?\d{2,3}[\s.\-]?\d{3}[\s.\-]?\d{3,4}(?!\d)""")
    private val email = Regex("""[\w.+\-]+@[\w\-]+\.[\w.]+""")
    private val placeholder = Regex("""\[CẦN BỔ SUNG[^\]]*\]|\[GỢI Ý VÍ DỤ[^\]]*\]""")

    fun scan(text: String): List<String> = buildList {
        if (phone.containsMatchIn(text)) add("Có số điện thoại. Chỉ giữ nếu là đường dây của đơn vị, không phải của trẻ em.")
        if (email.containsMatchIn(text)) add("Có địa chỉ email. Chỉ giữ nếu là email của đơn vị.")
        val n = placeholder.findAll(text).count()
        if (n > 0) add("Còn $n chỗ đánh dấu [CẦN BỔ SUNG] hoặc [GỢI Ý VÍ DỤ] cần xử lý trước khi đăng.")
    }
}

fun Context.copyToClipboard(label: String, text: String) {
    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    if (Build.VERSION.SDK_INT < 33) Toast.makeText(this, "Đã copy $label", Toast.LENGTH_SHORT).show()
}

fun Context.openUrl(url: String) {
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
