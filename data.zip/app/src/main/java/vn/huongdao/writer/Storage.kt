package vn.huongdao.writer

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Prefs(private val ctx: Context) {
    private val plain = ctx.getSharedPreferences("scout_writer", Context.MODE_PRIVATE)
    private fun buildSecure() = EncryptedSharedPreferences.create(
        ctx, "scout_writer_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // Keystore trên một số máy có thể làm hỏng file mã hoá; khi đó xoá file và tạo lại (phải nhập lại API key).
    private val secure by lazy {
        try { buildSecure() } catch (e: Exception) {
            ctx.deleteSharedPreferences("scout_writer_secure")
            buildSecure()
        }
    }

    var apiKey: String
        get() = secure.getString("api_key", "").orEmpty()
        set(v) { secure.edit().putString("api_key", v.trim()).apply() }

    var model: String
        get() = plain.getString("model", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL
        set(v) { plain.edit().putString("model", v.trim()).apply() }

    var thinking: String
        get() = plain.getString("thinking", null) ?: "MEDIUM"
        set(v) { plain.edit().putString("thinking", v).apply() }

    var customStyle: String
        get() = plain.getString("custom_style", null) ?: ""
        set(v) { plain.edit().putString("custom_style", v).apply() }

    fun skill(genre: Genre?): String = plain.getString(skillKey(genre), null)
        ?: if (genre == null) Defaults.GLOBAL_SKILL else Defaults.GENRE_SKILLS.getValue(genre)

    fun setSkill(genre: Genre?, text: String) { plain.edit().putString(skillKey(genre), text).apply() }
    fun resetSkill(genre: Genre?) { plain.edit().remove(skillKey(genre)).apply() }
    private fun skillKey(g: Genre?) = "skill_" + (g?.key ?: "global")

    companion object { const val DEFAULT_MODEL = "gemini-4-hydrogen" }
}

internal class JsonFile(private val file: File) {
    fun exists() = file.exists()
    fun read(): JSONArray = try { JSONArray(file.readText()) } catch (e: Exception) { JSONArray() }
    fun write(a: JSONArray) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(a.toString())
        if (!tmp.renameTo(file)) { file.writeText(a.toString()); tmp.delete() }
    }
}

private inline fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> = List(length()) { f(getJSONObject(it)) }

private fun Version.toJson() = JSONObject()
    .put("id", id).put("title", title).put("body", body).put("social", social)
    .put("hashtags", JSONArray(hashtags)).put("notes", notes)
    .put("label", label).put("createdAt", createdAt)

private fun JSONObject.toVersion(): Version {
    val tags = optJSONArray("hashtags")
    return Version(
        getString("id"), optString("title"), optString("body"), optString("social"),
        if (tags == null) emptyList() else List(tags.length()) { tags.getString(it) },
        optString("notes"), optString("label"), optLong("createdAt")
    )
}

private fun Article.toJson() = JSONObject()
    .put("id", id).put("genre", genreKey).put("style", styleId)
    .put("brief", brief).put("keywords", keywords).put("updatedAt", updatedAt)
    .put("versions", JSONArray().also { a -> versions.forEach { a.put(it.toJson()) } })

private fun JSONObject.toArticle(): Article {
    val vs = optJSONArray("versions") ?: JSONArray()
    return Article(
        getString("id"), optString("genre"), optString("style", "thieu_nien"),
        optString("brief"), optString("keywords"),
        vs.mapObjects { it.toVersion() }, optLong("updatedAt")
    )
}

private fun Term.toJson() = JSONObject().put("id", id).put("term", term).put("meaning", meaning).put("avoid", avoid)
private fun JSONObject.toTerm() = Term(getString("id"), optString("term"), optString("meaning"), optString("avoid"))

class ArticleRepo(ctx: Context) {
    private val f = JsonFile(File(ctx.filesDir, "articles.json"))
    fun load(): List<Article> = f.read().mapObjects { it.toArticle() }.sortedByDescending { it.updatedAt }
    fun save(all: List<Article>) = f.write(JSONArray().also { a -> all.forEach { a.put(it.toJson()) } })
}

class TermRepo(ctx: Context) {
    private val f = JsonFile(File(ctx.filesDir, "terms.json"))
    fun load(): List<Term> = if (f.exists()) f.read().mapObjects { it.toTerm() } else Defaults.SEED_TERMS
    fun save(all: List<Term>) = f.write(JSONArray().also { a -> all.forEach { a.put(it.toJson()) } })
}
