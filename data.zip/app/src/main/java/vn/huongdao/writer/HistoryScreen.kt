package vn.huongdao.writer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    var importing by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Article?>(null) }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi", "VN")) }

    ScreenScaffold("Bài đã tạo", onBack, actions = {
        TextButton(onClick = { importing = true }) { Text("Dán bài có sẵn") }
    }) { pad ->
        if (vm.articles.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize().padding(24.dp)) {
                Text("Chưa có bài nào. Tạo bài ở màn hình chính, hoặc dán một bài có sẵn để tiếp tục chỉnh sửa và tạo phiên bản mới.")
            }
        } else {
            LazyColumn(
                Modifier.padding(pad),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.articles, key = { it.id }) { a ->
                    Card(onClick = { vm.open(a.id); onBack() }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(a.displayTitle, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                                Text(
                                    "${Genre.fromKey(a.genreKey).label}, ${a.versions.size} phiên bản, ${fmt.format(Date(a.updatedAt))}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { toDelete = a }) { Icon(Icons.Default.Delete, contentDescription = "Xoá bài") }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { a ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Xoá bài này?") },
            text = { Text("Xoá \"${a.displayTitle}\" cùng ${a.versions.size} phiên bản. Không khôi phục được.") },
            confirmButton = { TextButton(onClick = { vm.deleteArticle(a.id); toDelete = null }) { Text("Xoá") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Huỷ") } }
        )
    }

    if (importing) {
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { importing = false },
            title = { Text("Dán bài có sẵn") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dùng cho bài viết từ nơi khác (Gemini app, AI Studio, Word). Bài sẽ thành phiên bản đầu tiên để bạn điều chỉnh tiếp.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(title, { title = it }, label = { Text("Tiêu đề") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(body, { body = it }, label = { Text("Nội dung (Markdown hoặc văn bản)") }, minLines = 6, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = body.isNotBlank(), onClick = {
                    vm.importArticle(title, body); importing = false; onBack()
                }) { Text("Thêm") }
            },
            dismissButton = { TextButton(onClick = { importing = false }) { Text("Huỷ") } }
        )
    }
}
