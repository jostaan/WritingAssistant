package vn.huongdao.writer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(vm.prefs.apiKey) }
    var show by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(vm.prefs.model) }
    var thinking by remember { mutableStateOf(vm.prefs.thinking) }

    ScreenScaffold("Cài đặt", onBack) { pad ->
        Column(
            Modifier.padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionTitle("Gemini API key")
            Text(
                "Đăng nhập Google AI Studio, tạo API key rồi dán vào đây. Key lưu mã hoá trên máy này và chỉ gửi tới Google. Mỗi người dùng nên dùng key riêng.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = { ctx.openUrl("https://aistudio.google.com/apikey") }) { Text("Mở Google AI Studio") }
            OutlinedTextField(
                value = key, onValueChange = { key = it; vm.prefs.apiKey = it },
                label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Ẩn" else "Hiện") } }
            )

            SectionTitle("Model")
            OutlinedTextField(
                value = model, onValueChange = { model = it; vm.prefs.model = it },
                label = { Text("Tên model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            SectionTitle("Mức suy luận")
            Text(
                "Viết bài không cần mức cao. MEDIUM cân bằng tốc độ và chất lượng; HIGH (mặc định của model) chậm và tốn token hơn. Temperature bị gemini-4-hydrogen bỏ qua nên app không có tuỳ chọn này; độ khác biệt giữa các phiên bản do prompt tạo ra.",
                style = MaterialTheme.typography.bodySmall
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("LOW", "MEDIUM", "HIGH", "XHIGH").forEach { lv ->
                    FilterChip(selected = thinking == lv, onClick = { thinking = lv; vm.prefs.thinking = lv }, label = { Text(lv) })
                }
            }

            Button(onClick = { vm.testConnection() }) { Text("Kiểm tra kết nối") }
            vm.testResult?.let { Text(it) }
        }
    }
}
