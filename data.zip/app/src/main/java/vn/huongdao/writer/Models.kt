package vn.huongdao.writer

enum class Genre(val key: String, val label: String) {
    DIEM_TIN("diem_tin", "Điểm tin"),
    THONG_CAO("thong_cao", "Thông cáo / Thông báo"),
    TUONG_THUAT("tuong_thuat", "Tường thuật"),
    PHONG_SU("phong_su", "Phóng sự"),
    NGHI_LUAN("nghi_luan", "Nghị luận"),
    CHUYEN_DE("chuyen_de", "Bài chuyên đề"),
    DUOI_CO("duoi_co", "Câu chuyện dưới cờ");

    companion object {
        fun fromKey(k: String): Genre = entries.firstOrNull { it.key == k } ?: TUONG_THUAT
    }
}

enum class Adjust(val label: String) {
    CONCISE("Cô đọng hơn"),
    DETAILED("Cụ thể hơn"),
    DEEPER("Sâu sắc hơn"),
    PRACTICAL("Thực tiễn hơn"),
    CONTINUE("Viết tiếp")
}

data class StylePreset(val id: String, val label: String, val prompt: String)

data class Version(
    val id: String,
    val title: String,
    val body: String,
    val social: String,
    val hashtags: List<String>,
    val notes: String,
    val label: String,
    val createdAt: Long
)

data class Article(
    val id: String,
    val genreKey: String,
    val styleId: String,
    val brief: String,
    val keywords: String,
    val versions: List<Version>,
    val updatedAt: Long
) {
    val displayTitle: String
        get() = versions.lastOrNull()?.title?.takeIf { it.isNotBlank() }
            ?: brief.lineSequence().firstOrNull { it.isNotBlank() }?.take(60)
            ?: "Bài chưa đặt tên"
}

data class Term(val id: String, val term: String, val meaning: String, val avoid: String)
