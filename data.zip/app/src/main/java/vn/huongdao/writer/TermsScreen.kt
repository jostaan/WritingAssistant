package vn.huongdao.writer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TermsScreen(vm: MainViewModel, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Term?>(null) }
    var bulk by remember { mutableStateOf(false) }
    val list = vm.terms.filter {
        query.isBlank() || it.term.contains(query, ignoreCase = true) || it.meaning.contains(query, ignoreCase = true)
    }

    ScreenScaffold("Thuật ngữ (${vm.terms.size})", onBack, actions = {
        TextButton(onClick = { bulk = true }) { Text("Nhập hàng loạt") }
        IconButton(onClick = { editing = Term("", "", "", "") }) { Icon(Icons.Default.Add, contentDescription = "Thêm thuật ngữ") }
    }) { pad ->
        Column(Modifier.padding(pad).imePadding()) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, label = { Text("Tìm thuật ngữ") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            Text(
                "Danh sách khởi tạo chưa được duyệt. Ban Huấn luyện cần rà soát trước khi dùng chính thức. Toàn bộ danh sách được gửi kèm mỗi lần tạo bài.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { t ->
                    Card(onClick = { editing = t }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(t.term, style = MaterialTheme.typography.titleMedium)
                            Text(t.meaning, style = MaterialTheme.typography.bodyMedium)
                            if (t.avoid.isNotBlank()) {
                                Text("Tránh: ${t.avoid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { t ->
        TermDialog(
            initial = t,
            onDismiss = { editing = null },
            onSave = { vm.saveTerm(it); editing = null },
            onDelete = if (t.id.isBlank()) null else ({ vm.deleteTerm(t.id); editing = null })
        )
    }
    if (bulk) BulkDialog(onDismiss = { bulk = false }, onImport = { vm.importTerms(it); bulk = false })
}

@Composable
private fun TermDialog(initial: Term, onDismiss: () -> Unit, onSave: (Term) -> Unit, onDelete: (() -> Unit)?) {
    var term by remember { mutableStateOf(initial.term) }
    var meaning by remember { mutableStateOf(initial.meaning) }
    var avoid by remember { mutableStateOf(initial.avoid) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id.isBlank()) "Thêm thuật ngữ" else "Sửa thuật ngữ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(term, { term = it }, label = { Text("Thuật ngữ") }, singleLine = true)
                OutlinedTextField(meaning, { meaning = it }, label = { Text("Giải thích") }, minLines = 2)
                OutlinedTextField(avoid, { avoid = it }, label = { Text("Cách dùng cần tránh (không bắt buộc)") })
            }
        },
        confirmButton = {
            TextButton(
                enabled = term.isNotBlank() && meaning.isNotBlank(),
                onClick = { onSave(initial.copy(term = term.trim(), meaning = meaning.trim(), avoid = avoid.trim())) }
            ) { Text("Lưu") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Xoá") }
                TextButton(onClick = onDismiss) { Text("Huỷ") }
            }
        }
    )
}

@Composable
private fun BulkDialog(onDismiss: () -> Unit, onImport: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nhập hàng loạt") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Mỗi dòng một thuật ngữ: Thuật ngữ | Giải thích | Cách dùng cần tránh (không bắt buộc). Thuật ngữ trùng tên sẽ được thay thế.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(text, { text = it }, minLines = 6, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onImport(text) }) { Text("Nhập") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Huỷ") } }
    )
}
