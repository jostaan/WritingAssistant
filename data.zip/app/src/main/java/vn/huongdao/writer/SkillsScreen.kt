package vn.huongdao.writer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkillsScreen(vm: MainViewModel, onBack: () -> Unit) {
    var sel by remember { mutableStateOf<Genre?>(null) }
    var text by remember(sel) { mutableStateOf(vm.prefs.skill(sel)) }

    ScreenScaffold("Skills: quy tắc viết bài", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(selected = sel == null, onClick = { sel = null }, label = { Text("Quy tắc chung") })
                Genre.entries.forEach { g ->
                    FilterChip(selected = sel == g, onClick = { sel = g }, label = { Text(g.label) })
                }
            }
            Text("Quy tắc chung áp dụng cho mọi thể loại; quy tắc thể loại được ghép thêm vào. Thay đổi lưu ngay và có hiệu lực ở lần tạo bài kế tiếp.")
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; vm.prefs.setSkill(sel, it) },
                label = { Text(sel?.label ?: "Quy tắc chung") },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            TextButton(onClick = { vm.prefs.resetSkill(sel); text = vm.prefs.skill(sel) }) { Text("Khôi phục mặc định") }
        }
    }
}
