package vn.huongdao.writer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel

enum class Screen { EDITOR, HISTORY, SKILLS, TERMS, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.EDITOR) }
    BackHandler(enabled = screen != Screen.EDITOR) { screen = Screen.EDITOR }
    val back = { screen = Screen.EDITOR }
    when (screen) {
        Screen.EDITOR -> EditorScreen(vm) { screen = it }
        Screen.HISTORY -> HistoryScreen(vm, back)
        Screen.SKILLS -> SkillsScreen(vm, back)
        Screen.TERMS -> TermsScreen(vm, back)
        Screen.SETTINGS -> SettingsScreen(vm, back)
    }
}
