package vn.huongdao.writer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: MainViewModel, onNav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(vm.prefs.customStyle) }
    val gap = Arrangement.spacedBy(8.dp)

    ScreenScaffold("Viết bài Hướng đạo", null, actions = {
        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Menu") }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Bài mới") }, onClick = { menu = false; vm.newArticle() })
            DropdownMenuItem(text = { Text("Bài đã tạo") }, onClick = { menu = false; onNav(Screen.HISTORY) })
            DropdownMenuItem(text = { Text("Skills: quy tắc viết bài") }, onClick = { menu = false; onNav(Screen.SKILLS) })
            DropdownMenuItem(text = { Text("Thuật ngữ Hướng đạo") }, onClick = { menu = false; onNav(Screen.TERMS) })
            DropdownMenuItem(text = { Text("Cài đặt") }, onClick = { menu = false; onNav(Screen.SETTINGS) })
        }
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionTitle("Thể loại")
            FlowRow(horizontalArrangement = gap, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Genre.entries.forEach { g ->
                    FilterChip(selected = vm.genre == g, onClick = { vm.genre = g }, label = { Text(g.label) })
                }
            }
            if (vm.genre == Genre.DUOI_CO) Text(Defaults.FLAG_HINT, style = MaterialTheme.typography.bodySmall)

            SectionTitle("Phong cách")
            FlowRow(horizontalArrangement = gap, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Defaults.STYLES.forEach { s ->
                    FilterChip(selected = vm.styleId == s.id, onClick = { vm.styleId = s.id }, label = { Text(s.label) })
                }
                FilterChip(selected = vm.styleId == "custom", onClick = { vm.styleId = "custom" }, label = { Text("Tuỳ chọn") })
            }
            if (vm.styleId == "custom") {
                OutlinedTextField(
                    value = custom, onValueChange = { custom = it; vm.prefs.customStyle = it },
                    label = { Text("Mô tả phong cách của bạn") }, minLines = 3, modifier = Modifier.fillMaxWidth()
                )
            }

            SectionTitle("Nội dung")
            OutlinedTextField(
                value = vm.brief, onValueChange = { vm.brief = it },
                label = { Text("Nội dung chính (mỗi ý một gạch đầu dòng)") },
                minLines = 5, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = vm.keywords, onValueChange = { vm.keywords = it },
                label = { Text("Từ khoá cần nhấn mạnh") }, minLines = 2, modifier = Modifier.fillMaxWidth()
            )

            Button(onClick = { vm.generate() }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
                if (vm.busy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Đang viết…")
                } else {
                    Text(if (vm.current?.versions.isNullOrEmpty()) "Tạo bài" else "Tạo phiên bản mới")
                }
            }
            vm.errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            val art = vm.current
            val v = vm.selected
            if (art != null && v != null) {
                SectionTitle("Phiên bản")
                FlowRow(horizontalArrangement = gap, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    art.versions.forEachIndexed { i, ver ->
                        FilterChip(selected = i == vm.versionIndex, onClick = { vm.selectVersion(i) }, label = { Text("v${i + 1}") })
                    }
                }
                Text(v.label, style = MaterialTheme.typography.bodySmall)

                SectionTitle("Điều chỉnh")
                FlowRow(horizontalArrangement = gap, verticalArrangement = gap) {
                    Adjust.entries.forEach { m ->
                        OutlinedButton(onClick = { vm.adjust(m) }, enabled = !vm.busy) { Text(m.label) }
                    }
                }

                val warnings = SafetyCheck.scan(v.title + "\n" + v.body + "\n" + v.social)
                if (warnings.isNotEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Kiểm tra trước khi đăng", style = MaterialTheme.typography.titleSmall)
                            warnings.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
                if (v.notes.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Ghi chú cần xử lý", style = MaterialTheme.typography.titleSmall)
                            Text(v.notes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                SectionTitle("Bài đề xuất đăng báo, website")
                OutlinedTextField(
                    value = v.title, onValueChange = { vm.editSelected(title = it) },
                    label = { Text("Tiêu đề") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = v.body, onValueChange = { vm.editSelected(body = it) },
                    label = { Text("Nội dung (Markdown)") }, minLines = 10, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = gap) {
                    Button(onClick = { ctx.copyToClipboard("Markdown", "# ${v.title}\n\n${v.body}") }) { Text("Copy Markdown") }
                    Button(onClick = {
                        ctx.copyToClipboard("HTML", "<h1>${Md.escape(v.title)}</h1>\n${Md.toHtml(v.body)}")
                    }) { Text("Copy HTML") }
                }

                SectionTitle("Nội dung mạng xã hội")
                OutlinedTextField(
                    value = v.social, onValueChange = { vm.editSelected(social = it) },
                    label = { Text("Bài đăng Facebook") }, minLines = 5, modifier = Modifier.fillMaxWidth()
                )
                if (v.hashtags.isNotEmpty()) {
                    Text(v.hashtags.joinToString(" "), color = MaterialTheme.colorScheme.primary)
                }
                Button(onClick = {
                    val tags = if (v.hashtags.isEmpty()) "" else "\n\n" + v.hashtags.joinToString(" ")
                    ctx.copyToClipboard("nội dung mạng xã hội", v.social.trim() + tags)
                }) { Text("Copy") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
